/*

sqflite: ^2.2.8+4
path_provider: ^2.0.15
*/



import 'package:flutter/material.dart';
import 'user_form_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  MaterialApp materialApp = MaterialApp(
    debugShowCheckedModeBanner: false,
    home: UserFormScreen(),
  );

  runApp(materialApp);
}
